# RTLRefine: known-bug comparison and checked repair

Run `python3 -m streamlit run rtl_app.py` and open `/benchmarks` for the new
comparison. The completed frozen cohort contains nine historical public
research-artifact defect versions and two healthy controls. Self-review repaired
2/9; execution feedback repaired 3/9. Both share the first proposal and have
at most two logical calls. Each arm used 18 logical calls; physical calls are
counted once: 25 requests, estimated $1.014992, no unsettled requests in this run.

A healthy-code rewrite passed the public test and failed both extra audits.
It remained rejected without an extra request. Both methods kept one of two
normal controls unchanged. Both failed six real cases. Every compile, policy,
parse and trace failure stays in the record. A one-case difference is an
observed cohort outcome, not statistical or general superiority.

The oracle uses published expected output traces and two transformed/generated
audit traces whose outputs were captured from a corrected control before
inference. This is golden-trace agreement, not independent behavioral proof or
unbounded correctness. It is separate from the older authored queue experiment
and the older negative nine-pair comparison. Current sources/checker hashes
remained unchanged during the frozen run; no functional manual repair was made.

The editable benchmark workspace can rerun these exact supported modules with
native Yosys 0.51, Verilator 4.038, g++, make, bubblewrap and prlimit on Linux.
Unspecified initialization is zero, matching the research artifact. Browsing
and fresh checks make no API call. Optional live repair is a server-enabled
explicit action under the persistent budget cap. The default container can
browse recorded results but disables new native checks without the pinned
native tools. Existing Icarus/Yosys workflows remain available.

See `docs/KNOWN_BUG_BENCHMARK.md` for the full protocol, exclusions, oracle
scope and reproduction. The sealed dataset and raw model records are supplied.
`scripts/fetch_known_bug_artifact.py` can retrieve and hash-check the licensed
upstream subset; do not regenerate/overwrite a frozen cohort in place.

Vendor MIT/GPL-3.0-or-later licenses and complete original/modified sources are
included. Xilinx-generated source with unclear redistribution licensing is not
included. The root MIT license applies to project-authored code and does not
replace vendor licensing. Public-source training contamination is possible.
No public deployment, YouTube upload, Devpost submission or human study is
represented as complete. Keys, private budget state and tool binaries are absent.

## Earlier external UART extension

Run `python3 -m streamlit run rtl_app.py` and open `/uart` for the new external
historical case, or `/mutation` for the earlier synthetic queue experiment.

The external case is a real ZipCPU UART CTS/BREAK defect from another author
and project. A legal writer trusts a false not-busy signal and sends while the
receiver is blocking. Independent external-port/serial checks reproduce it.
No corrected UART RTL is used as the scoring oracle or given to NVIDIA.

All four paid development requests remain visible (estimated $0.174519). The
first incorrectly kept the broken source; the next two had output/patch failures.
The fourth exact model body passes 12 finite serial/flow checks and 80/96-step
CTS properties after an indentation-only controller boundary fix. The initial
parser rejection, exact parser diff and requalified original/maintainer controls
are retained. Simulation and formal checkers did not change. This post-hoc
recheck is not a prospectively frozen four-call success or a held-out accuracy
result. Small divisors and computed parity were excluded before inference after
maintainer-control calibration failures, also retained.

See `docs/EXTERNAL_UART.md`. Vendor and derived UART RTL are GPL-3.0-or-later,
with original notices, license, corresponding source and modification notice.
Project-authored Python remains under the root MIT license. A test build needs
Linux unprivileged namespaces; there is no unisolated RTL execution fallback.

The older synthetic results and negative 9-pair historical comparison remain
separate. Public hosting, repository publication, YouTube, Devpost submission and
human usability testing are not claimed complete. No key, private budget ledger
or installed tool binary is included in this source bundle.

## Earlier synthetic challenge

New entry: run `python3 -m streamlit run rtl_app.py` and open `/mutation`.
The intentionally injected queue faults are checked without a corrected RTL
implementation. The scorer uses public properties and independent Python deque.
This is an explicitly synthetic experiment on one authored queue.

The frozen eight-case run accepted repairs for **6/6 injected candidates** within
two requests each. Four passed on the first request. One of two healthy controls
was kept unchanged; the other was unnecessarily rewritten and still passed the
contract. All 11 real Nebius requests and the three initial policy rejections
remain recorded. Estimated API cost: $0.226926. No model output is hand-repaired.

The grader never reads pristine RTL or the mutation map. Six finite simulation
profiles and 2-word/16-step plus 4-word/12-step property checks define acceptance.
Twelve original counterexample inputs reproduced failures in Icarus and Python.
Audit observations neither enter repair feedback nor control another request.
The clean source and map are included under `research/` for post-run audit only;
the runtime container does not need those files. See `docs/MUTATION_CHALLENGE.md`.

The demonstrated faults are manufactured; these results do not establish new
real-world bug discovery, a general repair rate, an external held-out benchmark,
unbounded correctness or algorithmic novelty. This protocol is separate from
the earlier historical 3/9 self-review versus 2/9 feedback cohort.

The source ZIP includes both the new lab and the older historical workflow.
Its own manifest covers every exported source/evidence file. No credentials,
private spending ledger or installed tool binaries are included.

## Historical workflow and setup

A browser workspace for three real sequential RTL bugs: FIFO reset flush, AXI
byte validity and frame-FIFO backpressure. Edit or upload the supported module,
run fresh independent checks, inspect the diff and export exact checked bytes
with evidence. NVIDIA Nemotron Ultra on Nebius Token Factory proposes repairs;
the independent evaluator owns the contracts, testbenches and reference sources.

## Run

On Linux with Docker and unprivileged namespace support:

```sh
docker compose up --build
```

Open http://127.0.0.1:8501. The container has no key, no `.env` and no original
spending state. Manual verification and recorded results need no model API.
See `docs/DEPLOYMENT.md` for native Linux setup, the required namespace options
and optional live-model server settings. The image runs as a non-root user and
does not use privileged mode or add SYS_ADMIN.

The focused entry point is `python3 -m streamlit run rtl_app.py`. Python 3.13,
Yosys 0.51, Icarus/vvp 11.0, bubblewrap and util-linux/prlimit are the tested
toolchain. UI dependencies are pinned in `requirements-ui.lock`.

## What is verified

Only the three pinned modules and stated parameters are supported. The gate
requires all 12 directed regressions across the case set and the applicable
bounded comparisons: 16 steps for reset, four 20-step profiles for byte masks,
12 steps for the frame FIFO. A single review checks its selected case, not all
three at once. This is not unbounded correctness, CDC sign-off, all-parameter
coverage or a general arbitrary-RTL service.

Source ports, license, configuration guards and directives remain fixed.
The reference criterion includes exact ready/valid timing and can conservatively
reject alternative legal implementations. See `docs/RTL_CONTRACT_AUDIT.md`.

## Real model results

The complete fixed cohort has nine paired trials, with a shared first NVIDIA
proposal and the same two-call cap. Self-review accepts 3/9; checker feedback
accepts 2/9. It uses 23 unique paid requests at an estimated $0.798303.
There is no demonstrated feedback advantage. Full failures, prompts, responses,
executed source and controller hashes are in `demo/sequential_comparison`.
An interrupted two-request pilot is retained separately, not pooled.

Examples distinguish the historical maintainer control, accepted NVIDIA fixes,
an AXI partial repair rejected at 4/6 tests, and a frame proposal that passes
three simulations but fails bounded reference agreement. Historical public bugs
may have appeared in training data; this is not a blind benchmark or a new bug
discovery. No generated RTL is manually repaired to earn acceptance.

## Reproduce

```sh
python3 -m pip install 'pytest>=8,<9'
python3 -m pytest -q tests
```

The focused tests cover source policy, the real frame failure/control, malformed
tool traces, exact-review eligibility, default-off paid actions and worker
serialization. They need a Linux host that allows bubblewrap namespaces for
actual EDA; otherwise those optional tool tests skip. No test calls a paid model.
The full development workspace's wider regression suite is recorded separately
in the release validation file. The unrelated earlier prototypes are not part
of this focused distribution.

The exported review ZIP contains the candidate, original, upstream license,
observations, scripts, logs, file manifest and checker source snapshots. The
file hash displayed in the UI identifies exactly which bytes were reviewed.

## Licensing and release status

Project source is MIT licensed. Original verilog-axis RTL and derivatives retain
their MIT notices and COPYING in each third-party directory and evidence bundle.
The original and maintainer commits are pinned in each `source.json`.

This is a functioning local test build. The owner's public repository, durable
hosted URL, YouTube upload and Devpost submission are separate publication steps.
Human designer evaluations have not been conducted; a protocol is supplied.
No testimonials, time savings, board results or algorithm-first claims are made.
