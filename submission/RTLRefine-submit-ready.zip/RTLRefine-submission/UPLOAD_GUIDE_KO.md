# 최종 제출 순서

영상 주소: https://youtu.be/JEvktXDIUd0

1. 영상 업로드와 비로그인 재생 가능 상태를 확인했습니다. 확인 당시에는
   **일부 공개(Unlisted)**였으므로 YouTube Studio에서 **공개(Public)**로
   변경합니다. 제목·설명을 다듬으려면 `YOUTUBE.md`를 사용합니다.
2. 위 영상 주소를 로그아웃 브라우저에서 열어 재생되는지 다시 확인합니다.
3. Devpost에서 `PROJECT_FIELDS.md`의 이름, 피치, 트랙, 저장소 주소와 테스트
   빌드 주소를 입력합니다. Video URL에는 실제 YouTube 주소를 넣습니다.
4. About the project에는 `DEVPOST_ABOUT.md`, 도구 피드백에는
   `NEBIUS_FEEDBACK.md`의 영문 내용을 붙여 넣습니다.
5. 갤러리에는 `screenshots/`의 PNG를 올립니다. 먼저 수정 diff와 검증 결과가
   함께 보이는 화면을 선택합니다.
6. 팀원과 본인 정보, 권리 확인 항목을 직접 검토하고 최종 제출합니다.
   초안 저장과 최종 제출은 다릅니다. 대회 제출 목록에서 상태를 확인합니다.

한국시간 마감: **2026년 10월 31일 오전 2시**. 여유를 두고 제출합니다.
공식 규정: https://nebiusglobalaihackathon.devpost.com/rules

공개 저장소와 실행 안내가 있는 테스트 빌드 경로를 사용합니다. 별도 유료
호스팅 가입은 필요하지 않습니다. Devpost의 Video URL에는 위 YouTube 주소를
입력합니다. 로컬 MP4 경로나 GitHub의 MP4 주소를 입력하지 않습니다.

기본 빌드는 저장된 NVIDIA 응답 열람과 로컬 재검증, 업로드 프로젝트 검증을
키 없이 제공합니다. 새 추론은 운영자 키가 있어야 활성화됩니다. 이를
무제한 공개 추론 서비스로 설명하지 않습니다.
