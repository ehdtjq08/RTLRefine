`ifndef RTLREFINE_CHECK_VH
`define RTLREFINE_CHECK_VH
`define RTLREFINE_DONE(CHECKS) begin $display("RTLREFINE_PASS nonce=7664e96018927e230d51c9cd035a038d checks=%0d", (CHECKS)); $finish; end
`endif
