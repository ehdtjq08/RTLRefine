`ifndef RTLREFINE_CHECK_VH
`define RTLREFINE_CHECK_VH
`define RTLREFINE_DONE(CHECKS) begin $display("RTLREFINE_PASS nonce=2939fd47c71cb17075ac952a2fd78654 checks=%0d", (CHECKS)); $finish; end
`endif
