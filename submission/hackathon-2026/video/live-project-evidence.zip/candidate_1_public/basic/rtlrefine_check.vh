`ifndef RTLREFINE_CHECK_VH
`define RTLREFINE_CHECK_VH
`define RTLREFINE_DONE(CHECKS) begin $display("RTLREFINE_PASS nonce=192c377b09272aa215df575046bd6b6e checks=%0d", (CHECKS)); $finish; end
`endif
