`ifndef RTLREFINE_CHECK_VH
`define RTLREFINE_CHECK_VH
`define RTLREFINE_DONE(CHECKS) begin $display("RTLREFINE_PASS nonce=1f058a6c80ed6ea798dcb3989a77561a checks=%0d", (CHECKS)); $finish; end
`endif
